// vue.config.js
module.exports = {
    // options...
    devServer: {
        proxy: 'http://ec2-18-139-110-142.ap-southeast-1.compute.amazonaws.com:3000/',
    }
  }