<template>
    <div>
      <p id='header'> Add New Home </p>
      <v-container fluid id='inputHome' v-if="HomeID == 0">
        <v-row align="center">
            <v-col>
                <p id="subheader">Home Name</p>
                <v-text-field id="Home" label="Home Name" type="text" v-model="home" required :disabled='false'></v-text-field>
                <v-btn id='HomeBtn' style="float:right;" @click="addHome()" :disabled='false'>Done Adding Home</v-btn>
            </v-col>
        </v-row>
        <v-row align="center" style="visibility:hidden;" id="Room">
            <v-col>
                <p id="subheader">Add Room</p>
                <v-row 
                    v-for="item in i"
                    :key="item">
                    <v-col>
                      <v-text-field id="RoomTxt" label="Room Name" type="text" v-model="room_name[item-1]" required></v-text-field>
                    </v-col>
                    <v-col>
                      <select class="form-control" id="actionBox" v-model="room_type[item-1]" style="margin-top:12px">
                        <option :value="choices[c-1]" v-for="c in choices.length" :key="c" >{{choices[c-1]}}</option>
                      </select>
                    </v-col>
                </v-row>
                <br>
                <v-btn id="RoomMoreBtn" style="float:right;" @click="addMore(i)" >Add More</v-btn>
                <v-btn id="RoomAddBtn" style="float:right;" @click="addRoom()" >Done Adding Room</v-btn>
            </v-col>
        </v-row>
      </v-container>
      <v-container fluid id='inputHome' v-else>
        <v-row align="center">
            <v-col>
                <p id="subheader">Home Name</p>
                <v-text-field id="Home" label="Home Name" type="text" v-model="home" required :disabled='true'></v-text-field>
                <v-btn id='HomeBtn' style="float:right;" @click="addHome()" :disabled='true'>Done Adding Home</v-btn>
            </v-col>
        </v-row>
        <v-row align="center" style="visibility:visible;" id="Room">
            <v-col>
                <p id="subheader">Add Room</p>
                <v-row 
                    v-for="item in i"
                    :key="item">
                    <v-col>
                      <v-text-field id="RoomTxt" label="Room Name" type="text" v-model="room_name[item-1]" required></v-text-field>
                    </v-col>
                    <v-col>
                      <select class="form-control" id="actionBox" v-model="room_type[item-1]" style="margin-top:12px">
                        <option :value="choices[c-1]" v-for="c in choices.length" :key="c" >{{choices[c-1]}}</option>
                      </select>
                    </v-col>
                </v-row>
                <br>
                <v-btn id="RoomMoreBtn" style="float:right;" @click="addMore(i)" >Add More</v-btn>
                <v-btn id="RoomAddBtn" style="float:right;" @click="addRoom()" >Done Adding Room</v-btn>
            </v-col>
        </v-row>
      </v-container>
    </div>
</template>

<script>
import axios from 'axios'
  export default {
    name:'ForceAddHome',
    data () {
      return {
        aws_url:'http://ec2-18-141-56-39.ap-southeast-1.compute.amazonaws.com:3000/',
        token:'',
        i:1,
        HomeID:'',
        room_name:[],
        room_type:[],
        home:'',
        Data:{
          message:'',
          HomeID:''
        },
        Data_room:{
          message: [{
            RoomID: '',
            Name:'',
            Type:''
          }]
        },
        choices:[
          'Living room',
          'Bathroom',
          'Bedroom'
        ] 
      }
    },async beforeMount(){
        // getting token
        this.token = await firebase.auth().currentUser.getIdToken();
        console.log('TokenID: ',this.token)
        // get homeID from url
        this.HomeID = this.$route.params.HomeID
    },
    methods:{
    addMore(i){
        this.i +=1;
    },
    addHome(){
        console.log("Adding Home",this.home)
        let info ={
            idToken: this.token,
            name: this.home
        } 
        var result = axios.post(this.aws_url+'admin/addHome',info)
        .then((res) =>{
            this.Data = res.data
            console.log("Data",this.Data)
// need to get id for home to add room
            document.getElementById('Room').style = 'visible'
            document.getElementById('Home').disabled = true
            document.getElementById('Home').color = "red"
            document.getElementById('HomeBtn').disabled = true
      })
      .catch(e=>{
          console.log(e)
      })
    },
    addRoom(){
        // console.log("Adding Room",this.room_name,this.room_type)
        let info = {
          idToken: this.token,
          HomeID: '',
          message:[]
        }
        for(var i = 0; i < this.room_name.length; i++){
          var temp = {
            name : this.room_name[i],
            type : this.room_type[i]
          }
          info.message.push(temp)
        }
        if(this.HomeID == 0){
          info.HomeID =this.Data.HomeID 
        }else{
          info.HomeID = this.HomeID 
        }
        // console.log("info",info)
        var result = axios.post(this.aws_url+'admin/addRoom',info)
        .then((res) =>{
            this.Data_room = res.data
            console.log("Data",this.Data_room)
            if(this.HomeID == 0){
              console.log("Home",this.Data.HomeID)
              this.$router.replace('/AddResident/'+this.Data.HomeID)
            }else{
              console.log("Home",this.HomeID)
              this.$router.replace('/Home/')
            }
        })
        .catch(e=>{
            console.log(e)
        })
    }
  }
}
</script>

<style scoped>
p#header{
  font-size: 40px; 
  font-family: arial;
  color: #000000;
  text-align:center;
}
p#subheader{
  font-size: 20px; 
  font-family: arial;
  color: black;
  background-color:#feb33b; 
}
#inputHome{
  width: 70%;
}
#HomeBtn,#RoomMoreBtn,#RoomAddBtn{
  background-color:#94acdf; 
  color:black;
  font-size:15px;
  font-family: arial;
  margin-bottom: 5px;
}
</style>