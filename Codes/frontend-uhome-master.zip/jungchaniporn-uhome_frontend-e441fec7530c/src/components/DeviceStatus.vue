<template>
  <!-- <v-card height="500px"> -->
    <v-container class="grey lighten-5">
    <v-row no-gutters>
      <v-col>
        <SlideBar>
        </SlideBar>
      </v-col>
      <v-col cols="9">
      <p id='header'> Device Status </p>
      <v-container
      class="pa-2"
      fluid>
      <v-row>
        <v-col
          v-for="data in Data"
          :key="data.name"
          :cols="3"
        >
        <v-dialog
      v-model="dialog"
      width="500"
    >
      <template v-slot:activator="{ on }">
          <v-card height="100px" width="200px" v-on="on">
            <!-- <v-img
              :src="card.src"
              class="white--text"
              gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
            >
            </v-img> -->
            <v-card-title
                class="fill-height align-end"
                v-text="data.name"
                style="font-size:20px; font-family: arial;"
              ></v-card-title>
            <v-card-actions>
              <div class="flex-grow-1"></div>
              <label class="switch">
                <input type="checkbox" checked @click="change(data)">
                <span class="slider round"></span>
              </label>
              <!-- <span style="font-size: 20px; "> &nbsp;&nbsp;{{data.status}}</span> -->
            </v-card-actions>
          </v-card>
          </template>
          <v-card>
        <v-card-title
          class="headline grey lighten-2"
          primary-title
        >
          Delete
        </v-card-title>

        <v-card-text>
          Please make sure that you want to delete!!
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="primary"
            text
            @click="deleteDevice(data)"
          >
            I accept
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
        </v-col>
      </v-row>
    </v-container>
      </v-col>
    </v-row>
  </v-container>
  <!-- </v-card> -->
</template>

<script>
import axios from 'axios'
import firebase from 'firebase'
import SlideBar from './SlideBar'
import dotenv from 'dotenv'
dotenv.config()
export default {
    name:'DeviceStatus',
    components:{ 'SlideBar': SlideBar },
    data () {
      return {
        aws_url:'http://ec2-18-141-56-39.ap-southeast-1.compute.amazonaws.com:3000/',
        token:'',
        dialog: false,
        Data:[{
          _id:'default',
          uid:'default',
          name:'default',
          enabled:true,
          on: false
        }],
        DataRes:[{
          did: '',
          enabled: ''
        }],
      }
    },
    async beforeMount(){
      // console.log(process.env.test)
      // getting token
      this.token = await firebase.auth().currentUser.getIdToken();
      console.log('TokenID: ',this.token)
      let body = {idToken: this.token}
      var result = await axios.post(this.aws_url+'api/device/get',body)
      .then((res) =>{
        this.Data = res.data
        console.log(this.Data)
      })
      .catch(e=>{
        console.log(e)
      })

    },
    methods:{
      change(data){
        var objIndex = this.Data.findIndex((obj => obj.name == data.name))    
        this.Data[objIndex].enabled=!this.Data[objIndex].enabled;
        console.log("change: ", this.Data[objIndex].enabled, "_id: ",this.Data[objIndex]._id);

        let toggleBody = {
          idToken: this.token,
          _id: this.Data[objIndex]._id,
          enabled: this.Data[objIndex].enabled
        }
        var result = axios.post(this.aws_url+'api/setEnabled',toggleBody)
        .then((res) =>{
          console.log("Successfully send")
          this.DataRes = res.data
          console.log(this.DataRes)
        })
        .catch(e=>{
          console.log(e)
        })
      },
      deleteDevice(data){
        var objIndex = this.Data.findIndex((obj => obj.name == data.name))
        this.dialog = false
        console.log("ID for delete: ",this.Data[objIndex]._id,", with token: ", this.token)
        let del_body = {
            idToken: this.token,
            _id: this.Data[objIndex]._id
          }
          console.log("delete", del_body)
          // api to delete device
          var result = axios.post(this.aws_url+'api/device/delete/',del_body)
          .then((res) =>{
              console.log("Delete",res.data)
              window.location.reload()
          })
          .catch(e=>{
              console.log("Delete error",e)
          })
      }
    }
  }
</script>

<style scoped>
p#header{
  font-size: 40px; 
  font-family: arial;
  color: #000000;
  text-align:center;
}
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}
input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}
.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

</style>