<template>
  <!-- <v-card height="500px"> -->
    <v-container class="grey lighten-5">
    <v-row no-gutters>
      <v-col >
        <v-navigation-drawer
          absolute
          permanent
          left
        >
      <template v-slot:prepend>
        <v-list-item two-line>
          <v-list-item-avatar>
            <img src="https://cdn.shopify.com/s/files/1/0713/7997/products/mobile-accessories-moomin-joy-popsocket-1_768x.jpg?v=1541102911">
          </v-list-item-avatar>

          <v-list-item-content>
            <v-list-item-title>Moomin</v-list-item-title>
            <v-list-item-subtitle>Logged In</v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>
      </template>

      <v-divider></v-divider>

      <v-list dense>
        <v-list-item
          v-for="item in items"
          :key="item.title"
        >
          <v-list-item-icon>
            <v-icon >{{ item.icon }}</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title style="text-align:left;">{{ item.title }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>
      </v-col>

      <v-col cols="9">
      <p id='header'> Rule Modification </p>
      <v-container fluid>
        <v-row align="center">
            <v-col >
              <p>Conditions</p>
                <v-select :options="conditions"></v-select>
            </v-col>
            <v-col >
              <p>Actions</p>
                <v-select :options="actions"></v-select>
            </v-col>
        </v-row>
      </v-container>
      </v-col>
    </v-row>
  </v-container>
  <!-- </v-card> -->
</template>

<script>
  export default {
    data () {
      return {
        items: [
          { title: 'Status', icon: 'mdi-home-city' },
          { title: 'Setup', icon: 'mdi-account' },
          { title: 'Manager', icon: 'mdi-account-group-outline' },
          { title: 'List Items', icon: 'mdi-account-group-outline' },
          { title: 'Event Log', icon: 'mdi-account-group-outline' },
          { title: 'Logout', icon: 'mdi-account-group-outline' },
        ],
        conditions:[
            'New Rule',
            'Modify Rule',
            'Delete Rule'
        ],
        actions:[
            'Create',
            'Edit',
            'Delete'
        ]
      }
    },
  }
</script>

<style scoped>
p#header{
  font-size: 40px; 
  color: #000000;
  text-align:center;
}
</style>