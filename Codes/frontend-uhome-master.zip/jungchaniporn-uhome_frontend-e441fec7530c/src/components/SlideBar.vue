<template style="height:1000px;">
    <v-navigation-drawer
          absolute
          permanent
          left
          id="main_slide"
        >
      <template v-slot:prepend>
        <v-list-item two-line>
          <v-list-item-avatar>
              <img :src="User.photoUrl" id="profileImg" >
            <!-- <img src="https://cdn.shopify.com/s/files/1/0713/7997/products/mobile-accessories-moomin-joy-popsocket-1_768x.jpg?v=1541102911"> -->
          </v-list-item-avatar>

          <v-list-item-content>
            <v-list-item-title id="Name">{{User.name}}</v-list-item-title>
            <v-list-item-title id="Email">{{User.email}}</v-list-item-title>
            <v-list-item-subtitle id="Status">Logged In</v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>
      </template>

      <v-divider></v-divider>

      <v-list dense>
        <v-list-item
        class="menu"
        v-for="item in items"
        :key="item.title"
        @click="menuClicked(item)"
        >
            <v-list-item-title id="ItemTitle">{{ item.title }}</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>
</template>

<script>
import firebase from 'firebase'
export default {
    name:'SlideBar',
    data(){
        return{
        items: [
          { title: 'Home' },
          // { title: 'Status' },
          { title: 'Add Devices'},
          { title: 'Elderly Danger Alert' },
          { title: 'Routine'},
          { title: 'Logout' },
        ],
        User:{
            name:'',
            email:'',
            photoUrl:'', 
            uid:'', 
            emailVerified:''
        }
        }
    },
    beforeMount() {
        var user = firebase.auth().currentUser;

        if (user != null) {
        this.User.name = user.displayName;
        this.User.email = user.email;
        if(user.photoURL!=null){
            this.User.photoUrl = user.photoURL;
        }else{
            this.User.photoUrl = 'https://cdn.shopify.com/s/files/1/0713/7997/products/mobile-accessories-moomin-joy-popsocket-1_768x.jpg?v=1541102911'
        }
        this.User.emailVerified = user.emailVerified;
        this.User.uid = user.uid;  
}
    },
    methods:{
      menuClicked(clickedItem){
        console.log(clickedItem)
        switch(clickedItem.title){
          case 'Logout':
            firebase.auth().signOut()
            .then((user)=> {
              this.user = null;
              console.log("Signing Out!!")
              this.$router.replace('/Login')
              console.log("Signed Out!!")
              location.reload()
            }).catch(function(error) {
              console.log(error)
            });
            break
          case 'Home':
            this.$router.replace('/Home/')
            break  
          case 'Status':
            this.$router.replace('/DeviceStatus/')
            break
          case 'Elderly Danger Alert':
            this.$router.replace('/Setup/')
            break
          case 'Routine':
            this.$router.replace('/Routine')
            break
          case 'Add Devices':
            this.$router.replace('/AddDevices')
            break
        }
      },
    }
}
</script>
<style>
#Name{
  font-size: 15px;
  font-family: arial;
  color: rgb(0, 0, 0);
}
#Email{
  font-size: 10px;
  font-family: arial;
  color: rgb(0, 0, 0);
}
#Status{
  font-size: 15px;
  font-family: arial;
  color: rgb(0, 0, 0);
}
#ItemTitle{
  text-align:left; 
  font-size: 20px;
  font-family: arial;
  height: 30px;
  color: rgb(0, 0, 0);
}
/* #ItemTitle:hover{
  color: white;
} */
.menu {
  margin: 5px;
  border-radius: 4px;
}
.menu:hover {
  background: #94acdf;
}
.menu:active {
  background: rgba(4, 2, 117, 0.267);
}
.theme--light.v-divider {
  border-color: rgb(255, 255, 255) !important; 
}
#main_slide{
  background-color:#feb33b;
}

</style>