<template>
  <v-container class="grey lighten-5">
    <v-row no-gutters>
      <v-col>
        <SlideBar style="height:1000px;">
        </SlideBar>
      </v-col>
      <v-col cols="9">
        <p id='header'> {{$route.params.RoomName}}</p>
        <p id="subheader">Hue</p>
        <v-row>
        <v-col
          v-for="data_Hue in Data_Hue.message"
          :key="data_Hue.Name"
          :cols="4"
        >
        <v-card class="mx-auto" max-width="auto" min-height="auto" max-height="400">
            <v-card-title
            v-text="data_Hue.Name"
            style="font-size:18px; font-family: arial;"
            ></v-card-title>
            <p>
              <v-btn id="btn" @click="delHue(data_Hue)">Del</v-btn>
            </p>
        </v-card>
        </v-col>
      </v-row>
      <v-divider></v-divider>
        <p id="subheader">Estimote</p>
        <v-row>
        <v-col
          v-for="data_Estimote in Data_Estimote.message"
          :key="data_Estimote.Name"
          :cols="4"
        >
        <v-card class="mx-auto" max-width="auto" min-height="auto" max-height="400">
            <v-card-title
            v-text="data_Estimote.Name"
            style="font-size:18px; font-family: arial;"
            ></v-card-title>
            <p>
              <v-btn id="btn" @click="delEstimote(data_Estimote)">Del</v-btn>
            </p>
        </v-card>
        </v-col>
      </v-row>

      </v-col>
    </v-row>
  </v-container>
</template>
<script>
import axios from 'axios'
import firebase from 'firebase'
import SlideBar from './SlideBar'
export default {
    name:'EachRoom',
    components:{ 'SlideBar': SlideBar },
    data () {
      return {
        aws_url:'http://ec2-18-141-56-39.ap-southeast-1.compute.amazonaws.com:3000/',
        token:'',
        RoomID:'',
        Data_Hue:{
          message: [{
            DeviceID: '',
            Name:'',
            on:''
          }]
        },
        Data_Estimote:{
          message: [{
            DeviceID: '',
            Name:''          
          }]
        }
      }
    },
    async beforeMount(){
      // getting token
      this.token = await firebase.auth().currentUser.getIdToken();
      console.log('TokenID: ',this.token)
      this.RoomID = this.$route.params.RoomID
      console.log("bfmount roomid", this.RoomID)
      let body = {
        idToken: this.token,
        RoomID: this.RoomID
      }
      // getting list of device Hue
      var result = await axios.post(this.aws_url+'user/getDevices/Hue',body)
      .then((res) =>{
        this.Data_Hue = res.data
        console.log("Hue list",this.Data_Hue)
      })
      .catch(e=>{
        console.log(e)
      }) 
      // getting list of device Estimote
      var result = await axios.post(this.aws_url+'user/getDevices/Estimote/Beacon/Show',body)
      .then((res) =>{
        this.Data_Estimote = res.data
        console.log("Estimote list",this.Data_Estimote)
      })
      .catch(e=>{
        console.log(e)
      }) 
    },
    methods:{
      delHue(data){
        console.log("Delete Hue", data.DeviceID)
        let body = {
          idToken: this.token,
          DeviceID: data.DeviceID
        }
        var result = axios.post(this.aws_url+'delete/device',body)
        .then((res) =>{
          console.log(res)
          window.location.reload();
        })
        .catch(e=>{
          console.log(e)
        })
      },
      delEstimote(data){
        console.log("Delete Estimote", data.DeviceID)
        let body = {
          idToken: this.token,
          DeviceID: data.DeviceID
        }
        var result = axios.post(this.aws_url+'delete/device',body)
        .then((res) =>{
          console.log(res)
          window.location.reload();
        })
        .catch(e=>{
          console.log(e)
        })
      },
    }
  }
</script>

<style scoped>
p#header{
  font-size: 40px; 
  font-family: arial;
  color: #000000;
  text-align:center;
}
p#subheader{
  font-size: 25px; 
  font-family: arial;
  color: #000000;
  text-align:left;
}
.theme--light.v-divider {
  border-color: rgb(0, 0, 0) !important; 
}
#btn{
  background-color:#94acdf; 
  color:black;
  font-size:15px;
  font-family: arial;
  margin-bottom: 5px;
}
</style>