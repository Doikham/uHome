<template>
  <div class="text-center">
    <v-progress-circular
      :size="50"
      color='rgba(182, 247, 166)'
      indeterminate
    ></v-progress-circular>

    <v-progress-circular
      :width="3"
      color='rgba(191, 163, 247)'
      indeterminate
    ></v-progress-circular>

    <v-progress-circular
      :size="70"
      :width="7"
      color='rgba(163, 225, 247)'
      indeterminate
    ></v-progress-circular>

    <v-progress-circular
      :width="3"
      color='rgba(233, 247, 163)'
      indeterminate
    ></v-progress-circular>

    <v-progress-circular
      :size="50"
      color= 'rgba(255, 0, 0, 0.5)'
      indeterminate
    ></v-progress-circular>
  </div>
</template>
<script>
import axios from 'axios'
import firebase from 'firebase'
export default {
  name: 'Loading',
    data () {
      return {
        aws_url:'http://ec2-18-141-56-39.ap-southeast-1.compute.amazonaws.com:3000/',
        token:'',
        Data:{
          message:[{
            AdminID: '',
            UserID: ''
          }],
          admin: true,
        }
      }
    },async beforeMount(){
      console.log('Token',this.token)
      if(this.token ==''){
        this.token = await firebase.auth().currentUser.getIdToken();
        console.log('TokenID: ',this.token)
        let body = {idToken: this.token}
        var result = await axios.post(this.aws_url+'checkAdmin',body)
        .then((res) =>{
          this.Data = res.data
          console.log('Check admin',this.Data)
          if(this.Data.admin==true){
            console.log("Admin", this.Data.message[0].AdminID)
            this.$router.replace('/Home')
          }else{
            console.log("New User")
            this.$router.replace('/ForceAddHome/0')
          }
        })
        .catch(e=>{
          console.log(e)
        })
      }
    },
}
</script>

<style scoped>
.v-progress-circular {
  margin: 1rem;
  margin-top: 20% 
}
</style>