<template>
<!-- <div class='main' :style="{'background-image':'url(https://news.livingpatterntech.com/wp-content/uploads/2017/07/Smart-Home-Background-2-1.jpg)'}"> -->
  <!-- <div class='login'>
    <p id='header'> Login </p>
    <div id="firebaseui-auth-container"></div>
  </div> -->
  <div class="main" >
  <v-card
    class="banner"
    flat 
    height="500px"
    :img="sample" 
  > 
    <v-toolbar
      class="tool"
      dense
      floating
    >
      <p id='header'> Login </p>
      <div id="firebaseui-auth-container"></div>
    </v-toolbar>
  </v-card>
  <pre class="description">
    Uhome platform, a platform that can support the use of IoT devices in the home environment including add,
    remove or manage IoT devices. With an implemented mobile application, users can control the IoT devices
    in a smart home. uHome uses the data from other sources in order to automate the house based on their
    profile.
  </pre>
  <v-row>
    <v-col>
      <v-card class="items">
      <v-container>
        <v-row justify="space-between">
          <v-col cols="auto" v-for="app in App_src" :key="app">
            <v-img
              height="200"
              width="200"
              :src= app
            ></v-img>
          </v-col>
          <v-col>
            <p class="description">
              Description for applications  <br />
              - Mobile application is an interface for users <br />
              - Web application is an interface for admin
            </p>
          </v-col>
        </v-row>
      </v-container>
    </v-card>
    </v-col>
  </v-row>
    <v-card class="items">
      <v-container>
        <v-row justify="space-between">
          <v-col cols="auto" v-for="device in Device_src" :key="device">
            <v-img
              height="200"
              width="200"
              :src= device
            ></v-img>
          </v-col>
          <v-col>
            <p class="description">
              Description for devices <br />
              - Philip Hue can be turned on/off and changed color <br />
              - Estimote Location Beacon is used to detect people in the room
            </p>
          </v-col>
        </v-row>
      </v-container>
    </v-card>
  </div>
</template>

<script>
import firebase from 'firebase'
import * as firebaseui from 'firebaseui'

export default {
    name: 'Login',
    data () {
      return {
        sample: require('../assets/S__48586834.jpg'),
        account:{
          email:'',
          password:'',
        },
        Data:{
          message:'',
          admin: true
        },
        App_src:[
          'https://cdn1.productnation.co/stg/sites/6/best-highend-smartphone-th.jpg',
          'https://zdnet1.cbsistatic.com/hub/i/r/2019/12/03/e356637b-183e-49e5-b5f3-9122be9fd18b/resize/1200x900/3a0c20f4c22749385fedb363379b6be1/istock-827896866.jpg',
                 
        ],
        Device_src:[
          'https://i.pcmag.com/imagery/reviews/07qcFUcgHD38GWdmGsnzjAi-12.fit_scale.size_2698x1517.png',
          'https://amicus.com.sg/migration_prd/wp-content/uploads/2016/09/box_location_devkit.png',

        ]
        
      }
    },
    mounted(){
      var uiConfig = {
        // signInSuccessUrl: '/#/DeviceStatus',
        signInSuccessUrl: '/#/Loading',
        signInOptions:[
          firebase.auth.GoogleAuthProvider.PROVIDER_ID
        ]
      }
      var ui = new firebaseui.auth.AuthUI(firebase.auth());
      ui.start('#firebaseui-auth-container',uiConfig)
      
    },
  }
</script>

<style scoped>
.banner{
  margin: 0px;
}
.login{
  width: 30%;
  height: auto;
  float:center;
  margin-left: 35%;
  margin-right: 40%;
  margin-top: 2%;
  padding: 20px;
  border-style: solid;
  border-color: #000000;
  border-width: 5px;
  resize: both;

}
p#header{
  resize: both;
  font-weight: bold;
  margin: 2px;
  font-size: 20px; 
  color: black;
}
.tool{
  float: right;
  margin: 10px;
  width: auto;
  height: auto;
  background-color: #feb33b;
}
.items{
  margin: 1%;
}
.description{
  margin: 1%;
  font-size: 20px;
  text-align:start;
}
</style>

