<template>
    <v-container class="grey lighten-5">
    <v-row no-gutters>
      <v-col >
        <SlideBar style="height:1000px;">
        </SlideBar>
      </v-col>

      <v-col cols="9">
      <p id='header'> Routine</p>
      <v-row id="home_box" >
        <p id='subheader' style="margin-top:10px">Select home</p>
        <select class="form-control" id="homeBox" v-model="selected_homeName" @change="selected_home()" >
          <option  
            :value="data.Name"
            v-for="data in Data_home.message"
            :key="data.Name" 
          >
            {{data.Name}}
          </option>
        </select>
      </v-row>
      <v-row id="routine_box" style="visibility: hidden;">
        <v-col>
          <v-row>
            <v-col
              v-for="data in Data.message"
              :key="data"
              :cols="4"
            >
            <v-card class="mx-auto" max-width="auto" min-height="170" max-height="auto">
                <v-card-title
                v-text="data.Name"
                style="font-size:20px; font-family: arial;"
                ></v-card-title>
                <p id="text_routine">Action: {{data.Action}}</p>
                <p id="text_routine" v-if="data.Sunrise == true">Sunrise</p>
                <p id="text_routine" v-else-if="data.Sunset == true">Sunset</p>
                <p id="text_routine" v-else >Time: {{data.Hours}} : {{data.Minutes}}</p>
                <v-btn id="btn" @click="del(data)">-</v-btn>
                <br>
            </v-card>
            </v-col>
          </v-row>
          <v-row>
            <v-col>
              <v-btn id="addBtn" style="float:right;" @click="add()" >Add</v-btn>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
      <v-row id="add_routine_box" style="visibility: hidden;">
        <v-col>
          <v-row v-for="item in i" :key="item">
            <v-col>
              <v-row>
                <p id='subheader' style="margin-top:10px">Select routine</p>
                <select class="form-control" id="homeBox" v-model="selected_opt[item-1]"  >
                  <option  
                    :value="opt"
                    v-for="opt in routine_option"
                    :key="opt" 
                  >
                    {{opt}}
                  </option>
                </select>
              </v-row>
              <v-row v-if="selected_opt[item-1] == 'Custom'">
                <v-text-field 
                label="Time" 
                type="Time" 
                v-model="custom_time[item-1]" 
                placeholder="00:00"
                :rules="[rules.required]"
                @change="checkTime(custom_time[item-1],item-1)"></v-text-field>
              </v-row>
              <v-row v-else style="visibility:hidden;">
                <!-- try to set default time = 0 -->
                {{custom_time[item-1] = 0}}
              </v-row>
            </v-col>
            <v-col>
              <p id='subheader' style="margin-top:10px">Select light</p>
              <select class="form-control" id="homeBox" v-model="selected_light[item-1]"  >
                <option  
                  :value="data_light"
                  v-for="data_light in Data_light.message"
                  :key="data_light.Name"
                >
                  {{data_light.Name}}
                </option>
              </select>
            </v-col>
            <v-col>
              <p id='subheader' style="margin-top:10px">Select action</p>
              <select class="form-control" id="homeBox" v-model="selected_act[item-1]"  >
                <option  
                  :value="act"
                  v-for="act in routine_action"
                  :key="act"
                >
                  {{act}}
                </option>
              </select>
            </v-col>
          </v-row>
          <v-row>
            <v-col>
              <v-btn id="MoreBtn" style="float:right;" @click="addMore(i)" >Add More</v-btn>
            </v-col>
          </v-row>
          <v-row>
            <v-col>
              <v-btn id="addRoutineBtn" style="float:right;" @click="addRoutine()" >Add Routine</v-btn>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from 'axios'
import SlideBar from './SlideBar'
  export default {
    name:'Routine',
    components:{ 'SlideBar': SlideBar },
    data () {
      return {
        aws_url:'http://ec2-18-141-56-39.ap-southeast-1.compute.amazonaws.com:3000/',
        token:'',
        i:1,
        selected_homeName:'',
        selected_homeID:'',
        selected_light:[],
        selected_opt:[],
        selected_act:[],
        custom_time:[],
        location:{
          lat:'',
          lon:''
        },
        Data:{
          message: [{
            _id:'',
            DeviceID:'',
            HomeID:'',
            Hours:'',
            Minutes:'',
            Action:'',
            Sun:''
          }]
        },
        Data_home:{
          message: [{
            HomeID: '',
            Name:''
          }]
        },
        routine_option:[
          'Sunrise',
          'Sunset',
          'Custom'
        ],
        Data_light:{
          message: [{
            DeviceID: '',
            Name:'',
          }]
        },
        routine_action:[
          'On',
          'Off'
        ],
        hr: 0,
        min: 0,
        invalid: false,
        rules:{
          required: value => !!value ||'Required',
        }
      }
    },async beforeMount(){
      // getting token
      this.token = await firebase.auth().currentUser.getIdToken();
      console.log('TokenID: ',this.token)
      // get current location (lat,lon)
      navigator.geolocation.getCurrentPosition(
          position => {
            this.location.lat = position.coords.latitude
            this.location.lon = position.coords.longitude
            console.log('Current lat,lon: ',this.location)
          },
          error => {
            console.log(error.message);
          },
        )
      
      let body = {idToken: this.token,}
      // getting admin id
      var result = await axios.post(this.aws_url+'checkAdmin',body)
      .then((res) =>{
        this.Data_res = res.data
        console.log("AdminID : ",this.Data_res.message[0].AdminID)
        
      })
      .catch(e=>{
        console.log(e)
      })
      // getting home for this user
      let body_home = {
        idToken: this.token,
        adminID: this.Data_res.message[0].AdminID
      }
      var result = await axios.post(this.aws_url+'admin/getHome',body_home)
      .then((res) =>{
        this.Data_home = res.data
        console.log(this.Data_home)

      })
      .catch(e=>{
        console.log(e)
      })
    },
    methods:{
      addMore(i){
        this.i +=1;
        console.log('Current: ',this.selected_opt,this.custom_time,this.selected_act)
      },
      selected_home(){
        console.log("home",this.selected_homeName)
        var objIndex = this.Data_home.message.findIndex((obj => obj.Name == this.selected_homeName)) 
        this.selected_homeID = this.Data_home.message[objIndex].HomeID
        console.log("homeID",this.selected_homeID)
        document.getElementById("routine_box").style.visibility = 'visible'
        // getting routine
        let routine_body = {
            idToken: this.token,
            HomeID: this.selected_homeID
          }
          var result_routine = axios.post(this.aws_url+'routine/get',routine_body)
          .then((res) =>{
            this.Data = res.data
            console.log("Routine",res)
          })
          .catch(e=>{
            console.log(e)
          })
      },
      del(data){
        console.log('Del: ',data._id)
        let body = {
          idToken: this.token,
          _id: data._id
        }
        var result = axios.post(this.aws_url+'routine/delete',body)
        .then((res) =>{
          console.log(res)
          window.location.reload();
        })
        .catch(e=>{
          console.log(e)
        })
      },
      add(){
        // getting lights
        let light_body = {
            idToken: this.token,
            HomeID: this.selected_homeID
          }
          var result_light = axios.post(this.aws_url+'getAllLightsRoutine',light_body)
          .then((res) =>{
            this.Data_light = res.data
            console.log("Light",this.Data_light)
            if(this.Data_light.length == 0){
              alert('No data')
            }
          })
          .catch(e=>{
            console.log(e)
          })
        document.getElementById("add_routine_box").style.visibility = 'visible'
      },
      addRoutine(){
        console.log('Add routine',this.selected_light)
        if(this.invalid == false){
          for(var ind = 0; ind < this.i; ind++){
            let body = {
              idToken: this.token,
              DeviceID: this.selected_light[ind].DeviceID,
              HomeID: this.selected_homeID,
              Action: this.selected_act[ind],
            }
            if(this.selected_opt[ind] == 'Custom'){
              let temp = {
                Hours: this.custom_time[ind].substring(0,2),
                Minutes: this.custom_time[ind].substring(3,5)
              }
              // var hr = this.custom_time[ind].substring(0,2)
              // var min = this.custom_time[ind].substring(3,5)
              // console.log('Time: ', hr,':',min)
              body = Object.assign(body,temp)
            }else if(this.selected_opt[ind] == 'Sunrise'){
              let temp = {
                Sunrise: true,
                Lat: this.location.lat,
                Long: this.location.lon
              }
              body = Object.assign(body,temp)
            }else if(this.selected_opt[ind] == 'Sunset'){
              let temp = {
                Sunset: true,
                Lat: this.location.lat,
                Long: this.location.lon
              }
              body = Object.assign(body,temp)
            }
            console.log(body)
            var result = axios.post(this.aws_url+'routine/add',body)
            .then((res) =>{
              console.log("Add Routine",ind,": ",res)
              window.location.reload();
            })
            .catch(e=>{
              console.log(e)
            })
          }
        }else{
          alert('Cannot add routine. Please change custome time.')
        }
      },
      checkTime(custom_time,i){
        console.log('check time',i)
        var today = new Date()
        this.hr = today.getHours() 
        this.min = today.getMinutes()
        console.log('hr:min',this.hr,this.min)
        var temp_hr = custom_time.substring(0,custom_time.indexOf(':'))
        var temp_min = custom_time.substring(custom_time.indexOf(':')+1,5)
        this.invalid = this.hr+this.min
        console.log('input',Number(temp_hr),Number(temp_min))
        if(temp_hr == this.hr && temp_min == (this.min+1)){
          this.invalid = true
          alert('Invalid')
        }else{
          this.invalid = false
        }
      }
    }
  }
</script>

<style scoped>
p#header{
  font-size: 40px; 
  font-family: arial;
  color: #000000;
  text-align:center;
}
p#subheader{
  font-size: 20px; 
  font-family: arial;
  color: rgb(0, 0, 0);
  /* background-color:rgb(255, 255, 255);  */
}
#btn,#addRoutineBtn,#MoreBtn,#addBtn{
  background-color: #94acdf; 
  color:black;
  font-size:15px;
  font-family: arial;
}
#text_routine{
  font-size:15px; 
  margin-left:10px ;
  text-align:left; 
  font-family: arial;
}
</style>