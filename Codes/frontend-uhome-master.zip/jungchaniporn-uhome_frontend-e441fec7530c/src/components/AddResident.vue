<template>
    <div>
      <p id='header'> Add Resident </p>
      
      <v-container fluid id='inputHome'>
        <v-row align="center" id="Resident">
            <v-col>
                <p id="subheader">Add Resident</p>
                <v-text-field id="ResidentTxt" label="Resident Name" type="text" v-model="resident" required></v-text-field>

                <!-- <v-row 
                    v-for="item in i"
                    :key="item">
                    <v-text-field id="ResidentTxt" label="Resident Name" type="text" v-model="resident[item-1]" required></v-text-field>
                </v-row> -->
                <!-- <v-btn id="ResidentMoreBtn" style="float:right;" @click="addMore(i)" :disabled='false'>Add More</v-btn> -->
                <v-btn id="ResidentAddBtn" style="float:right;" @click="addResident()" :disabled='false'>Done Adding Resident</v-btn>
            </v-col>
        </v-row>
      </v-container>
    </div>
</template>

<script>
import axios from 'axios'
  export default {
    name:'AddResident',
    data () {
      return {
        aws_url:'http://ec2-18-141-56-39.ap-southeast-1.compute.amazonaws.com:3000/',
        token:'',
        i:1,
        HomeID:'',
        resident:'',
        Data:{
          message:''
        }
      }
    },async beforeMount(){
        // getting token
        this.token = await firebase.auth().currentUser.getIdToken();
        console.log('TokenID: ',this.token)
        // need to get id for home to add resident (homeID)
        this.HomeID = this.$route.params.HomeID
        console.log("bfmount homeid", this.HomeID)

    },
    methods:{
    addMore(i){
        this.i +=1;
    },
    addResident(){
        console.log(this.HomeID,"Adding Residents",this.resident)
        let info ={
            idToken: this.token,
            email: this.resident,
            homeID: this.HomeID
        } 
        var result = axios.post(this.aws_url+'user/addtoHome',info)
        .then((res) =>{
            this.Data = res.data
            console.log("Data",this.Data)
            if(this.Data.message == '1 record inserted'){
              this.$router.replace('/Home/')
            }else{
              alert("Invalid email!!")
            }
    })
    .catch(e=>{
        console.log(e)
    })
    }
  }
  }
</script>

<style scoped>
p#header{
  font-size: 40px; 
  font-family: arial;
  color: #000000;
  text-align:center;
}
p#subheader{
  font-size: 20px; 
  font-family: arial;
  color: black;
  background-color:#feb33b; 
}
#inputHome{
    width: 70%;
}
#ResidentAddBtn{
  background-color:#94acdf; 
  color:black;
  font-size:15px;
  font-family: arial;
  margin-bottom: 5px;
}
</style>