<template>
<!-- <v-card height="500px"> -->
    <v-container class="grey lighten-5">
    <v-row no-gutters>
      <v-col >
        <SlideBar>
        </SlideBar>
      </v-col>

      <v-col cols="9">
      <p id='header'> Elderly Danger Alert</p>
      <v-row id="home_box" >
        <p id='subheader' style="margin-top:10px">Select home</p>
        <select class="form-control" id="homeBox" v-model="selected_homeData" @change="selected_home()" >
          <option  
            :value="data"
            v-for="data in Data_home.message"
            :key="data.Name" 
          >
            {{data.Name}}
          </option>
        </select>
      </v-row>
      <v-row id="resident_box" style="visibility: hidden;">
        <v-col>
          <v-row v-if="Data_setting.message.length!=0">
            <v-col>
              <v-row>
                <p id='subheader'>Tracking resident: {{Data_setting.message[0].name}}</p>
              </v-row>
              <v-row>
                <v-col>
                <v-row>
                  <v-col>
                    <p id='subheader' style="margin-top:5px">Time spend before alert: </p>
                  </v-col>
                  <v-col>
                    <v-text-field 
                    label="Time in minutes" 
                    type="number" 
                    v-model="Data_setting.message[0].NotiTime" 
                    :rules="[rules.range]"
                    :disabled="this.Data_setting.message[0].Learn"
                    ></v-text-field>
                  </v-col> 
                </v-row>
                <v-row>
                  <v-col>
                    <p id='subheader' style="margin-top:5px">Enable smart learning: </p>
                  </v-col>
                  <v-col>
                    <v-btn id="btn" v-model="this.Data_setting.message[0].Learn" :value="this.Data_setting.message[0].Learn" @click="toggle_edit()">{{this.Data_setting.message[0].Learn}}</v-btn>
                  </v-col>
                </v-row>
                <v-row style="float:right;">
                  <v-btn id="btn" style="float:right;" @click="edit()">Confirm</v-btn>
                  &nbsp;
                  <v-btn id="btn" style="float:right;" @click="del()">Delete</v-btn>
                </v-row>
              </v-col>
              </v-row>
            </v-col>
          </v-row>
          <v-row v-else>
            <p id='subheader' style="margin-top:10px">Select resident</p>
            <select  class="form-control" id="homeBox" v-model="selected_user" @change="selected_resident()" >
              <option  
                :value="data"
                v-for="data in Data_resident.message"
                :key="data.Name" 
              >
                {{data.Name}}
              </option>
            </select>
          </v-row>
        </v-col>
      </v-row>
      <v-row id="setting_box" style="visibility: hidden;">
        <v-col>
          <v-row>
            <v-col>
              <p id='subheader' style="margin-top:5px">Time spend before alert: </p>
            </v-col>
            <v-col>
              <v-text-field 
              label="Time in minutes" 
              type="number" 
              v-model="timeNotification" 
              :rules="[rules.required,rules.range]"
              ></v-text-field>
            </v-col> 
          </v-row>
          <v-row>
            <v-col>
              <p id='subheader' style="margin-top:5px">Enable smart learning: </p>
            </v-col>
            <v-col>
              <v-btn id="btn" v-model="smart_learning" @click="toggle()">{{smart_learning}}</v-btn>
            </v-col>
          </v-row>
          <v-row>
            <v-col>
              <v-btn id="btn" style="float:right;" @click="add()">Add</v-btn>
            </v-col>
          </v-row>
        </v-col>
      </v-row>
          
      </v-col>
    </v-row>
  </v-container>
  <!-- </v-card> -->
</template>
<script>
import axios from 'axios'
import SlideBar from './SlideBar'
  export default {
    name:'Setup',
    components:{ 
      'SlideBar': SlideBar 
    },
    data: () => ({
    aws_url:'http://ec2-18-141-56-39.ap-southeast-1.compute.amazonaws.com:3000/',
    Data_home:{
      message: [{
        HomeID: '',
        Name:''
      }]
    },
    Data_setting:{
      message:[{
        HomeID:'',
        NotiTime:'',
        Learn: false,
        UserID:'',
        name:''
      }]
    },
    Data_resident:{
      message: [{
        HomeID: '',
        Name:'',
        UserID:'',
        Email:''
      }]
    },
    selected_homeData:'',
    selected_user:'',
    timeNotification:'',
    smart_learning: false,
    rules: {
      required: value => !!value ||'Required',
      range: value => value > 1 && value <= 59 || 'Invalid value',
    },
    }),
    async beforeMount() {
      this.token = await firebase.auth().currentUser.getIdToken();
      console.log('TokenID: ',this.token)

      let body = {idToken: this.token,}
      // getting admin id
      var result = await axios.post(this.aws_url+'checkAdmin',body)
      .then((res) =>{
        this.Data_res = res.data
        console.log("AdminID : ",this.Data_res.message[0].AdminID)
        
      })
      .catch(e=>{
        console.log(e)
      })
      // getting home for this user
      let body_home = {
        idToken: this.token,
        adminID: this.Data_res.message[0].AdminID
      }
      var result = await axios.post(this.aws_url+'admin/getHome',body_home)
      .then((res) =>{
        this.Data_home = res.data
        console.log(this.Data_home)

      })
      .catch(e=>{
        console.log(e)
      })
    },
    methods:{
      selected_home(){
        // console.log("homeID",this.selected_homeData.HomeID)
        let body = {
          idToken: this.token,
          HomeID: String(this.selected_homeData.HomeID)
        }
        console.log('get setting', body)
        var result = axios.post(this.aws_url+'setting/get',body)
        .then((res) =>{
          this.Data_setting = res.data
          console.log("Setting list",this.Data_setting)
        })
        .catch(e=>{
          console.log(e)
        })

        // getting list of resident
        var result = axios.post(this.aws_url+'admin/getUser',body)
        .then((res) =>{
          this.Data_resident = res.data
          console.log("Resident list",this.Data_resident)
          if(this.Data_resident.message.length!=0){
            document.getElementById("resident_box").style.visibility = 'visible'
          }else{
            alert("There is no resident")
          }
        })
        .catch(e=>{
          console.log(e)
        })
        
      },
      selected_resident(){
        console.log("userID",this.selected_user.UserID)
        document.getElementById("setting_box").style.visibility = 'visible'
      },
      toggle(){
        this.smart_learning = !this.smart_learning
        console.log(this.smart_learning)
      },
      toggle_edit(){
        this.Data_setting.message[0].Learn = !this.Data_setting.message[0].Learn
        console.log(this.Data_setting.message[0].Learn)
      },
      add(){
        let body = {
          idToken: this.token,
          HomeID: this.selected_homeData.HomeID,
          Time: this.timeNotification,
          Learn: this.smart_learning,
          UserID: this.selected_user.UserID
        }
        var result = axios.post(this.aws_url+'setting/add',body)
        .then((res) =>{
          console.log("Adding",res)
          window.location.reload()
        })
        .catch(e=>{
          console.log(e)
        })
      },
      edit(){
        let body = {
          idToken: this.token,
          HomeID: this.Data_setting.message[0].HomeID,
          Time: this.Data_setting.message[0].NotiTime,
          Learn: this.Data_setting.message[0].Learn,
          UserID: this.Data_setting.message[0].UserID
        }
        var result = axios.post(this.aws_url+'setting/edit',body)
        .then((res) =>{
          console.log("Editting",res)
          window.location.reload()
        })
        .catch(e=>{
          console.log(e)
        })
      },
      del(){
        let body = {
          idToken: this.token,
          HomeID: this.Data_setting.message[0].HomeID,
        }
        var result = axios.post(this.aws_url+'setting/delete',body)
        .then((res) =>{
          console.log("Delete",res)
          window.location.reload()
        })
        .catch(e=>{
          console.log(e)
        })
      }
    },
  }
</script>

<style scoped>
p#header{
  font-size: 40px; 
  color: #000000;
  text-align:center;
}
p#subheader{
  font-size: 20px; 
  color: rgb(0, 0, 0);
  /* background-color:rgb(255, 255, 255);  */
}
#btn{
  background-color: #94acdf; 
  color:black;
  font-size:15px;
}
</style>