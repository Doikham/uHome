<template>
  <v-container class="grey lighten-5">
    <v-row no-gutters>
      <v-col >
        <SlideBar style="height:1000px;">
        </SlideBar>
      </v-col>
      <v-col cols="9">
      <p id='header'> Add New Devices </p>
      <v-row id="home_box" >
        <p id='subheader' style="margin-top:10px">Select home</p>
        <select class="form-control" id="homeBox" v-model="selected_homeName" @change="selected_home()" >
          <option  
            :value="data.Name"
            v-for="data in Data_home.message"
            :key="data.Name" 
          >
            {{data.Name}}
          </option>
        </select>
      </v-row>
      <v-row id="room_box" style="visibility: hidden;">
        <p id='subheader' style="margin-top:10px">Select room</p>
        <select class="form-control" id="roomBox" v-model="selected_roomName" @change="selected_room()" >
          <option 
          :value="data.Name"
          v-for="data in Data_room.message"
          :key="data.Name"
          >
            {{data.Name}}
          </option>
        </select>
      </v-row>
      <v-row id="device_box" style="visibility: hidden;">
        <p id='subheader' style="margin-top:10px;">Select type of device</p>
        <select class="form-control" id="actionBox" v-model="selected_choice" @change="selecting_choice()">
          <option :value="choices[c-1]" v-for="c in choices.length" :key="c" >{{choices[c-1]}}</option>
        </select>
      </v-row>

      <v-row v-if="selected_choice === 'Hue'">
        <v-container fluid style="width:60%">
        <v-row align="center" id="hueCred">
          <v-col>
            <v-btn id="btn" @click="findHue" :disabled="hasHueCred">Get Code and State</v-btn>
            <v-btn id="btn" style="align:right" @click="sendCode()" :disabled="hasHueCred">Send Code and State</v-btn>
          </v-col>
        </v-row>
        <v-row id="light_box" style="visibility: hidden;">
        <!-- <p id='subheader' style="margin-top:10px;">Select light</p> -->
        <v-col>
          <v-row 
          v-for="data_light in Data_light.message"
          :key="data_light.Name">
            <input class="form-check-input" type="checkbox" id="inlineCheckbox1" @click="light(data_light)">
            <!-- <v-text-field id="light_txt" v-model="data_light.Name" :placeholder="data_light.Name"></v-text-field> -->
            <p id="light_txt"> &nbsp; {{data_light.Name}} <br> </p> 
          </v-row>
        </v-col>       
        </v-row>
        <v-row>
        <v-btn id="addHue" @click="addHue()" style="visibility: hidden;">
          Add Hue
        </v-btn>
      </v-row>
        </v-container>
      </v-row>
      
      <v-row v-else-if="selected_choice === 'Estimote'" >
        <v-container style="width:60%">
          <!-- for estimote -->
        <div id="estimote_box" style=" margin-top:10px;" >
        <p id='subheader'> Enter credential for estimote</p>
        <v-text-field id="AppID" label="App ID" v-model="appID" :disabled="estimoteExists"></v-text-field>
        <v-text-field id="AppToken" label="App Token" v-model="appToken" :disabled="estimoteExists"></v-text-field>
        </div>
        <v-btn id="btn" @click="getEstimote()">Get estimote</v-btn>
        <v-row id="all_estimote_box" style="visibility: hidden;">
          <v-col>
            <p id='subheader' style="margin-top:10px;">Select estimote</p>
            <select class="form-control" id="estimoteBox" v-model="selected_estimoteName" @change="selected_estimote()" >
              <option 
              :value="data.shadow.name"
              v-for="data in Data_estimote.message"
              :key="data.shadow.name"
              >
                {{data.shadow.name}}
              </option>
            </select>
            <v-row>
              <v-col>
                <p id='subheader' style="margin-top:10px;">Enter room size</p>
                <v-row>
                  <v-col>
                    <v-text-field id="roomSize" label="Width (Meters)" v-model="roomSize.width"></v-text-field>
                  </v-col>
                  <v-col>
                    <v-text-field id="roomSize" label="Length (Meters)" v-model="roomSize.length"></v-text-field>
                  </v-col>
                </v-row>
              </v-col>
            </v-row>
            <v-row>
              <v-btn id="btn" @click="addEstimote()" style=" margin-top:10px">Add estimote</v-btn>
            </v-row>
          </v-col>
        </v-row>
        </v-container>
      </v-row>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from 'axios'
import SlideBar from './SlideBar'
  export default {
    name:'AddDevice',
    components:{ 'SlideBar': SlideBar },
    data () {
      return {
        aws_url:'http://ec2-18-141-56-39.ap-southeast-1.compute.amazonaws.com:3000/',
        token:'',
        appID:'',
        appToken:'',
        roomSize:{
          width:'',
          length:''
        },
        estimoteExists:false,
        hasHueCred:false,
        enabled: false,
        Data:[{
            code:'',
            data:''
        }],
        Hue:[{
          text:'',
          url:''
        }],
        HueQuery:[{
          code:'',
          state:''
        }],
        selected_choice:'',
        selected_homeName:'',
        selected_roomName:'',
        selected_homeID:'',
        selected_roomID:'',
        selected_estimoteID:'',
        selected_estimoteName:'',
        selected_light:[],
        choices:[
          'Hue',
          'Estimote'
        ],
        Data_home:{
          message: [{
            HomeID: '',
            Name:''
          }]
        },
        Data_room:{
          message: [{
            RoomID: '',
            Name:'',
            Type:''
          }]
        },
        Data_res:{
          message:[{
            AdminID: '',
            UserID: ''
          }],
          admin: true,  
        },
        Data_light:{
          message: [{
            LightID: '',
            Name:'',
            Select:''
          }]
        },
        Data_estimote:{
          message:[]
        }
      }
    },
    async beforeMount() {
      // get token of current user
      this.token = await firebase.auth().currentUser.getIdToken()
      console.log(this.token)
      // get information from hue 
      // this.HueQuery.code = this.$route.query.code
      // this.HueQuery.state = this.$route.query.state
      // console.log("Param for hue",this.HueQuery.code,",state:",this.HueQuery.state)

      var curr_url = window.location.href
      this.HueQuery.code = curr_url.substring(curr_url.indexOf('code=')+5,curr_url.indexOf('&'))
      this.HueQuery.state = curr_url.substring(curr_url.indexOf('state=')+6,curr_url.indexOf('#'))
      console.log("Param for hue",this.HueQuery.code,",state:",this.HueQuery.state)

      let body = {idToken: this.token,}
      // getting admin id
      var result = await axios.post(this.aws_url+'checkAdmin',body)
      .then((res) =>{
        this.Data_res = res.data
        console.log("AdminID : ",this.Data_res.message[0].AdminID)
        
      })
      .catch(e=>{
        console.log(e)
      })
      // getting home for this user
      let body_home = {
        idToken: this.token,
        adminID: this.Data_res.message[0].AdminID
      }
      var result = await axios.post(this.aws_url+'admin/getHome',body_home)
      .then((res) =>{
        this.Data_home = res.data
        console.log(this.Data_home)

      })
      .catch(e=>{
        console.log(e)
      })
    },
    methods:{
      selected_home(){
        console.log("home",this.selected_homeName)
        if(this.selected_homeName!=null){ 
          var objIndex = this.Data_home.message.findIndex((obj => obj.Name == this.selected_homeName)) 
          this.selected_homeID = this.Data_home.message[objIndex].HomeID 
        }
        // var dataBox= document.getElementById("homeBox")
        // var data_id = dataBox.selectedIndex
        // var data_value = dataBox.value
        // this.selected_homeID = this.Data_home.message[data_id].HomeID
        console.log("homeID", this.selected_homeID)
        // getting list of room
        let body_room = {
          idToken: this.token,
          homeID: this.selected_homeID
        }
        // console.log("body_room", body_room)
        var result = axios.post(this.aws_url+'getRoom',body_room)
        .then((res) =>{
          this.Data_room = res.data
          console.log("Room list",this.Data_room)
          document.getElementById("room_box").style.visibility = 'visible'
        })
        .catch(e=>{
          console.log(e)
        })
      },
      selected_room(){
        console.log("room",this.selected_roomName)
        var objIndex = this.Data_room.message.findIndex((obj => obj.Name == this.selected_roomName)) 
        if(objIndex!=null){
          this.selected_roomID = this.Data_room.message[objIndex].RoomID
        }
        // var dataBox= document.getElementById("roomBox")
        // var data_id = dataBox.selectedIndex
        // var data_value = dataBox.value
        // this.selected_roomID = this.Data_room.message[data_id].RoomID
        console.log("roomID", this.selected_roomID)  
        document.getElementById("device_box").style.visibility = 'visible' 
      },
      selecting_choice(){
        console.log(this.selected_choice)
        if(this.selected_choice == 'Hue'){
          // check cred for hue
          let body = {
            idToken: this.token,
            HomeID: this.selected_homeID
          }
          var result = axios.post(this.aws_url+'checkHueCred',body)
          .then((res) =>{
            this.hasHueCred = res.data.hasHueCred
            console.log("Cred hue:",this.hasHueCred)
            if(this.hasHueCred == true){
              this.getLight()
            }
          })
          .catch(e=>{
            console.log(e)
          })

        }else if(this.selected_choice == 'Estimote'){
          // check estimote
          let body_check_est = {
            idToken: this.token,
            HomeID: this.selected_homeID
          }
          var result = axios.post(this.aws_url+'getEstimoteKey',body_check_est)
          .then((res) =>{
            console.log(res.data)
            this.appID = res.data.AppID
            this.appToken = res.data.AppToken
            this.estimoteExists = res.data.EstimoteKeyExists
            console.log("get estimote key",this.estimoteExists)
          })
          .catch(e=>{
            console.log(e)
          })
        }
      },
      selected_estimote(){
        console.log("estimote",this.selected_estimoteName)
        var objIndex = this.Data_estimote.message.findIndex((obj => obj.shadow.name == this.selected_estimoteName)) 
        this.selected_estimoteID = objIndex
        console.log(this.Data_estimote.message[this.selected_estimoteID])
      },
      findHue(){
        var me = this
        console.log('Finding hue')
        // send req to backend and get url to redirect for hue registeration
        let body = {
            idToken: this.token
        }
        var result = axios.post(this.aws_url+'api/addHueUser',body)
        .then((res) =>{
            this.Hue = res.data
            console.log("Data",this.Hue)
            window.location.href = this.Hue.url
        })
        .catch(e=>{
            console.log(e)
        })
      },
      addHue(){
        let info = {
          idToken: this.token,
          message:[]
        }
        for(var i = 0; i < this.Data_light.message.length; i++){
          if(this.Data_light.message[i].Select==true){
            let temp = {
              HomeID: this.selected_homeID,
              RoomID: this.selected_roomID,
              Name: this.Data_light.message[i].Name,
              LightID: this.Data_light.message[i].LightID
            }
            info.message.push(temp)
          }
        }
        console.log('Final Adding Light',info)
        var result = axios.post(this.aws_url+'admin/addDevice/Hue',info)
        .then((res) =>{
            console.log("add hue",res)
            this.$router.replace('/EachRoom/'+this.selected_roomID+'/'+this.selected_roomName)
        })
        .catch(e=>{
            console.log(e)
        })
      },
      sendCode(){
        console.log("Adding devices")
        // send hue information
        let hue_body = {
          idToken: this.token,
          code: this.HueQuery.code,
          state: this.HueQuery.state,
          HomeID: this.selected_homeID
        }
        var result = axios.post(this.aws_url+'api/addHueUser/callback',hue_body)
        .then((res) =>{
          console.log(res)
          alert("Done Adding Hue")
          this.getLight()
          if(this.Data_light.message.length==0 && this.selected_choice == 'Hue'){
            alert("There is no light to be added.")
            this.$router.replace('/EachHome/'+this.selected_homeID)
          }else if(this.Data_light.message.length!=0 && this.selected_choice == 'Hue'){
            document.getElementById("light_box").style.visibility = 'visible'
          }
        })
        .catch(e=>{
            console.log(e)
        })
      },
      getEstimote(){
        console.log("Getting Estimote",this.estimoteExists)
        if(this.estimoteExists==false){
          console.log("Estimote",this.appID,this.appToken)
          let estimote_body = {
            idToken: this.token,
            AppID: this.appID,
            AppToken: this.appToken,
            HomeID: this.selected_homeID
          }
          var result = axios.post(this.aws_url+'admin/add/Estimote/App',estimote_body)
          .then((res) =>{
            console.log("Done Adding Estimote",res)
            // alert("Done Adding Estimote")
            this.estimote()
          })
          .catch(e=>{
              console.log(e)
          })
        }else{
          this.estimote()
        }
        
      },
      estimote(){
        let estimote = {
          idToken: this.token,
          HomeID: this.selected_homeID
        }
        var ret = axios.post(this.aws_url+'admin/getDevice/Estimote/Beacon',estimote)
        .then((res) =>{
          console.log(res)
          this.Data_estimote = res.data
          console.log('List of estimote',this.Data_estimote)
          document.getElementById("all_estimote_box").style.visibility = 'visible'
        })
        .catch(e=>{
          console.log(e)
        })
      },
      addEstimote(){
        console.log('Room size: ',Number(this.roomSize.length),Number(this.roomSize.width))
        console.log('Adding Estimote',this.Data_estimote.message[this.selected_estimoteID])
        let estimote = {
          idToken: this.token,
          HomeID: this.selected_homeID,
          message: [{
            Name:this.Data_estimote.message[this.selected_estimoteID].shadow.name,
            RoomID:this.selected_roomID,
            Info: this.Data_estimote.message[this.selected_estimoteID]
          }],
          Length: Number(this.roomSize.length),
          Width: Number(this.roomSize.width)
        }
        var ret = axios.post(this.aws_url+'admin/addDevice/Estimote/Beacon',estimote)
        .then((res) =>{
          console.log(res)
          this.$router.replace('/EachRoom/'+this.selected_roomID+'/'+this.selected_roomName)
        })
        .catch(e=>{
          console.log(e)
        })
      },
      light(data){
        document.getElementById("addHue").style.visibility = 'visible'
        var out = data.Select
        console.log('light function', data,':',out)
        var objIndex = this.Data_light.message.findIndex((obj => obj.LightID == data.LightID)) 
        this.Data_light.message[objIndex].Select = !this.Data_light.message[objIndex].Select
        console.log('light', this.Data_light.message[objIndex])
      },
      getLight(){
        console.log('Get Light')
        // get light
        let light_body = {
          idToken: this.token,
          HomeID: this.selected_homeID
        }
        var result_light = axios.post(this.aws_url+'getAllLights',light_body)
        .then((res) =>{
          this.Data_light = res.data
          console.log("Light",this.Data_light)
          if(this.Data_light.message.length!=0 && this.selected_choice == 'Hue'){
            document.getElementById("light_box").style.visibility = 'visible'
          }else if(this.Data_light.message.length==0 && this.selected_choice == 'Hue'){
            alert("There is no light to be added.")
            this.$router.replace('/EachHome/'+this.selected_homeID)
          }
        })
        .catch(e=>{
          console.log(e)
        })
      },
      
    }
  }
</script>

<style scoped>
p#header{
  font-size: 40px; 
  font-family: arial;
  color: #000000;
  text-align:center;
}
p#subheader{
  font-size: 20px; 
  font-family: arial;
  color: #000000;
  text-align:right;
}
#light_txt{
  font-size: 15px; 
  font-family: arial;
}
#btn,#addHue{
  background-color: #94acdf; 
  color:black;
  font-size:15px;
  font-family: arial;
}
</style>