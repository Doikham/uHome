<template>
  <v-container class="grey lighten-5">
    <v-row no-gutters>
      <v-col>
        <SlideBar style="height:1000px;">
        </SlideBar>
      </v-col>
      <v-col cols="9">
        <!-- <p v-for="i in Data" :key="data.name"></p> -->
        <p id='header'> Home <v-btn id="btn" @click="addHome()" style="float:right;">Add</v-btn> </p>
        <v-row>
        <v-col
          v-for="data in Data.message"
          :key="data.Name"
          :cols="3"
        >
        <v-card class="mx-auto" max-width="auto" min-height="100" max-height="400">
            <v-card-title
            v-text="data.Name"
            style="font-size:20px; text-align:center; font-family: arial;"
            ></v-card-title>
            <v-btn id="btn" @click="delHome(data)">Del</v-btn>
            &nbsp;
            <v-btn id="btn" @click="eachHome(data)">Info</v-btn>
        </v-card>
        </v-col>
      </v-row>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from 'axios'
import firebase from 'firebase'
import SlideBar from './SlideBar'
export default {
    name:'Home',
    components:{ 'SlideBar': SlideBar },
    data () {
      return {
        aws_url:'http://ec2-18-141-56-39.ap-southeast-1.compute.amazonaws.com:3000/',
        token:'',
        Data:{
          message: [{
            HomeID: '',
            Name:''
          }]
        },
        Data_res:{
          message:[{
            AdminID: '',
            UserID: ''
          }],
          admin: true,
          
        }
      }
    },
    async beforeMount(){
      // getting token
      this.token = await firebase.auth().currentUser.getIdToken();
      console.log('TokenID: ',this.token)
      let body = {idToken: this.token,}
      // getting admin id
      var result = await axios.post(this.aws_url+'checkAdmin',body)
      .then((res) =>{
        this.Data_res = res.data
        console.log("AdminID : ",this.Data_res.message[0].AdminID)
        
      })
      .catch(e=>{
        console.log(e)
      })
    
      // getting home for this user
      let body_home = {
        idToken: this.token,
        adminID: this.Data_res.message[0].AdminID
      }
      var result = await axios.post(this.aws_url+'admin/getHome',body_home)
      .then((res) =>{
        this.Data = res.data
        console.log(this.Data)
      })
      .catch(e=>{
        console.log(e)
      })

    },
    methods:{
      delHome(data){
        var objIndex = this.Data.message.findIndex((obj => obj.HomeID == data.HomeID)) 
        console.log("Delete home",this.Data.message[objIndex].HomeID)
        let body = {
          idToken: this.token,
          HomeID: this.Data.message[objIndex].HomeID
        }
        var result = axios.post(this.aws_url+'delete/home',body)
        .then((res) =>{
          console.log(res)
          window.location.reload();
        })
        .catch(e=>{
          console.log(e)
        })
      },
      addHome(){
          this.$router.replace('/ForceAddHome/0')
      },
      eachHome(data){
        var objIndex = this.Data.message.findIndex((obj => obj.HomeID == data.HomeID)) 
        console.log("Go to home",objIndex)
        this.$router.replace('/EachHome/'+data.HomeID+'/'+data.Name)
      }
    }
  }
</script>

<style scoped>
p#header{
  font-size: 40px; 
  font-family: arial;
  color: #000000;
  text-align:center;
}
#btn{
  background-color: #94acdf; 
  color:black;
  font-size:15px;
  font-family: arial;
}
</style>