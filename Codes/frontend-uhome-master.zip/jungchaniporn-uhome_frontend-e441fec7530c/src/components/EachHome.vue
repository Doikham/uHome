<template>
  <v-container class="grey lighten-5">
    <v-row no-gutters>
      <v-col>
        <SlideBar style="height:1000px;">
        </SlideBar>
      </v-col>
      <v-col cols="9">
        <p id='header'><v-btn id="btn" style="float:left;" to="/Home">Back</v-btn> {{$route.params.HomeName}} </p>
        <p id="subheader">Room <v-btn id="btn" style="float:right;" @click="addRoom()">Add</v-btn> </p>
        <v-row>
        <v-col
          v-for="data_room in Data_room.message"
          :key="data_room.Name"
          :cols="4"
        >
        <v-card class="mx-auto" max-width="auto" min-height="auto" max-height="400">
            <v-card-title
            v-text="data_room.Name"
            style="font-size:18px; font-family: arial;"
            ></v-card-title>
            <v-btn id="btn" @click="delRoom(data_room)">Del</v-btn>
            &nbsp;
            <v-btn id="btn" @click="eachRoom(data_room)">Info</v-btn>
        </v-card>
        </v-col>
      </v-row>

      <v-divider></v-divider>
      <p id="subheader">Resident <v-btn id="btn" style="float:right;" @click="addRes()">Add</v-btn></p>
      <v-row>
        <v-col
          v-for="data_res in Data_resident.message"
          :key="data_res.Name"
          :cols="4"
        >
        <v-card class="mx-auto" max-width="auto" min-height="150" max-height="400">
            <v-card-title
            v-text="data_res.Name"
            style="font-size:18px; font-family: arial;"
            ></v-card-title>
            <p style="text-align:left; margin:10px; font-family: arial;">
              {{data_res.Email}}
            </p>
            <v-btn id="btn" @click="delRes(data_res)">Del</v-btn>
            &nbsp;
            <v-btn id="btn" @click="find_phone(data_res)">Find Phone</v-btn>
        </v-card>
        </v-col>
      </v-row>

      <v-divider></v-divider>
      <p id="subheader">Location</p>
      <v-row>
        <v-col
          v-for="data_loc in Data_location.message"
          :key="data_loc"
          :cols="4"
        >
        <v-card class="mx-auto" max-width="auto" min-height="150" max-height="400">
            <v-card-title
            v-text="data_loc.UserName"
            style="font-size:18px; font-family: arial;"
            ></v-card-title>
            <p style="text-align:left; margin:10px; font-family: arial;">
              {{data_loc.RoomName}}
            </p>
        </v-card>
        </v-col>
      </v-row>
      </v-col>
    </v-row>
  </v-container>
</template>
<script>
import axios from 'axios'
import firebase from 'firebase'
import SlideBar from './SlideBar'
export default {
    name:'EachHome',
    components:{ 'SlideBar': SlideBar },
    data () {
      return {
        aws_url:'http://ec2-18-141-56-39.ap-southeast-1.compute.amazonaws.com:3000/',
        token:'',
        HomeID:'',
        Data_room:{
          message: [{
            RoomID: '',
            Name:'',
            Type:''
          }]
        },
        Data_resident:{
          message: [{
            HomeID: '',
            Name:'',
            UserID:'',
            Email:''
          }]
        },
        Data_location:{
          message: [{
            UserID: '',
            RoomName:'',
            UserName:'',
            EnterTime:''
          }]
        },
      }
    },
    async beforeMount(){
      // getting token
      this.token = await firebase.auth().currentUser.getIdToken();
      console.log('TokenID: ',this.token)
      this.HomeID = this.$route.params.HomeID
      console.log("bfmount homeid", this.HomeID)
      let body = {
        idToken: this.token,
        homeID: this.HomeID
      }
      // getting list of room
      var result = await axios.post(this.aws_url+'getRoom',body)
      .then((res) =>{
        this.Data_room = res.data
        console.log("Room list",this.Data_room)
      })
      .catch(e=>{
        console.log(e)
      })
      // getting list of resident
      let body_res = {
        idToken: this.token,
        HomeID: this.HomeID
      }
      var result = await axios.post(this.aws_url+'admin/getUser',body_res)
      .then((res) =>{
        this.Data_resident = res.data
        console.log("Resident list",this.Data_resident)
      })
      .catch(e=>{
        console.log(e)
      })
      // getting list of location
      var result = await axios.post(this.aws_url+'home/getUserLocations',body_res)
      .then((res) =>{
        this.Data_location = res.data
        console.log("Location list",this.Data_location)
      })
      .catch(e=>{
        console.log(e)
      })

    },
    methods:{
      delRoom(data){
          console.log("Delete room",data.RoomID)
          let body = {
            idToken: this.token,
            RoomID: data.RoomID
          }
          var result = axios.post(this.aws_url+'delete/room',body)
          .then((res) =>{
            console.log(res)
            window.location.reload();
          })
          .catch(e=>{
            console.log(e)
          })
      },
      addRoom(){
        console.log("Add new room")
        this.$router.replace('/ForceAddHome/'+this.HomeID)
      },
      delRes(data){
        console.log("Delete resident",data.UserID)
        let body = {
            idToken: this.token,
            UserID: data.UserID,
            HomeID: this.HomeID
          }
          var result = axios.post(this.aws_url+'delete/userfromhome',body)
          .then((res) =>{
            console.log(res)
            window.location.reload();
          })
          .catch(e=>{
            console.log(e)
          })
      },
      addRes(){
        console.log("Add new resident")
        this.$router.replace('/AddResident/'+this.HomeID)
      },
      eachRoom(data){
        var objIndex = this.Data_room.message.findIndex((obj => obj.RoomID == data.RoomID)) 
        console.log("Go to room",objIndex)
        this.$router.replace('/EachRoom/'+data.RoomID+'/'+data.Name)
      },
      find_phone(data){
        console.log('Find phone of ',data.UserID)
        let body = {
          idToken: this.token,
          UserID: data.UserID
        }
        var result = axios.post(this.aws_url+'findPhone',body)
        .then((res) =>{
          console.log("Find Phone",res)
        })
        .catch(e=>{
          console.log(e)
        })
      }
    }
  }
</script>

<style scoped>
p#header{
  font-size: 40px; 
  font-family: arial;
  color: #000000;
  text-align:center;
}
p#subheader{
  font-size: 25px; 
  font-family: arial;
  color: #000000;
  text-align:left;
}
.theme--light.v-divider {
    border-color: rgb(0, 0, 0) !important; 
    
}
#btn{
  background-color: #94acdf; 
  color:black;
  font-size:15px;
  font-family: arial;
  margin-bottom: 5px;
}
</style>