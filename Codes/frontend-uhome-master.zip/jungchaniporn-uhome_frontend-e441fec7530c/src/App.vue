<template>
  <div id="app">
    <router-view/>
  </div>
</template>



<script>
// import JQuery from 'jquery'
// let $ = JQuery
// window.$ = require('jquery')
// window.JQuery = require('jquery')
export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #000000;
  margin-top: 0px;
}
img {
  align-content: left;
    width: 40px;
    height:auto;
    margin-top: 5px; 
}

</style>
